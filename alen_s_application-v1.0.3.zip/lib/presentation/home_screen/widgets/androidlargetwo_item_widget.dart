import 'package:flutter/material.dart';
import 'package:alen_s_application/core/app_export.dart';

// ignore: must_be_immutable
class AndroidlargetwoItemWidget extends StatelessWidget {
  const AndroidlargetwoItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return CustomImageView(
      imagePath: ImageConstant.imgImg16881,
      height: 243.v,
      width: 247.h,
    );
  }
}
