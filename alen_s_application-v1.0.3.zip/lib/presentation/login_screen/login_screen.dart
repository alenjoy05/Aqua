import 'package:alen_s_application/widgets/custom_text_form_field.dart';
import 'package:alen_s_application/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';
import 'package:alen_s_application/core/app_export.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController phoneNumberController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.whiteA700,
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 2.h,
                  vertical: 88.v,
                ),
                decoration: AppDecoration.fillOnPrimaryContainer,
                child: Column(
                  children: [
                    Text(
                      "Log In",
                      style: theme.textTheme.headlineSmall,
                    ),
                    SizedBox(height: 17.v),
                    _buildPhoneNumber(context),
                    SizedBox(height: 16.v),
                    _buildPassword(context),
                    SizedBox(height: 23.v),
                    _buildNext(context),
                    SizedBox(height: 13.v),
                    Text(
                      "or",
                      style: theme.textTheme.titleSmall,
                    ),
                    SizedBox(height: 13.v),
                    _buildContinueWithGoogle(context),
                    SizedBox(height: 15.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: Text(
                          "Forgot Password?",
                          style: theme.textTheme.titleSmall,
                        ),
                      ),
                    ),
                    SizedBox(height: 20.v),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Don’t have an account?",
                              style: CustomTextStyles.titleSmallffffffff,
                            ),
                            TextSpan(
                              text: " Sign up",
                              style: CustomTextStyles.titleSmallffff512b,
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    SizedBox(height: 20.v),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPhoneNumber(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 6.h,
        right: 7.h,
      ),
      child: CustomTextFormField(
        controller: phoneNumberController,
        hintText: "Enter Email or Phone Number",
        textInputType: TextInputType.emailAddress,
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 6.h,
        right: 7.h,
      ),
      child: CustomTextFormField(
        controller: passwordController,
        hintText: "Enter Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildNext(BuildContext context) {
    return CustomElevatedButton(
      text: "Next",
      margin: EdgeInsets.only(
        left: 6.h,
        right: 7.h,
      ),
    );
  }

  /// Section Widget
  Widget _buildContinueWithGoogle(BuildContext context) {
    return CustomElevatedButton(
      text: "Continue with Google",
      margin: EdgeInsets.only(
        left: 6.h,
        right: 7.h,
      ),
      leftIcon: Container(
        margin: EdgeInsets.only(right: 30.h),
        child: CustomImageView(
          imagePath: ImageConstant.imgImage1,
          height: 21.adaptSize,
          width: 21.adaptSize,
        ),
      ),
      buttonStyle: CustomButtonStyles.fillPrimaryContainer,
      buttonTextStyle: theme.textTheme.titleSmall!,
    );
  }
}
