class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Login images
  static String imgImage1 = '$imagePath/img_image_1.png';

  // Create account images
  static String imgVector = '$imagePath/img_vector.svg';

  // Home images
  static String imgUnion = '$imagePath/img_union.svg';

  static String imgImg16881 = '$imagePath/img_img_1688_1.png';

  static String imgImg16901 = '$imagePath/img_img_1690_1.png';

  static String imgImg16931 = '$imagePath/img_img_1693_1.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
