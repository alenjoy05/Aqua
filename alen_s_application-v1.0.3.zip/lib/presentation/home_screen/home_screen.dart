import 'widgets/androidlargetwo_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:alen_s_application/core/app_export.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 19.h,
            vertical: 20.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.only(right: 29.h),
                child: Text(
                  "Aquarium Management",
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 20.v),
              _buildSix(context),
              SizedBox(height: 3.v),
              _buildAndroidLargeTwo(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSix(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 6.h,
        right: 1.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 32.adaptSize,
            width: 32.adaptSize,
            decoration: BoxDecoration(
              color: appTheme.greenA700,
              borderRadius: BorderRadius.circular(
                16.h,
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgUnion,
            height: 31.v,
            width: 21.h,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAndroidLargeTwo(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.only(right: 1.h),
        child: ListView.separated(
          physics: BouncingScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (
            context,
            index,
          ) {
            return SizedBox(
              height: 1.v,
            );
          },
          itemCount: 5,
          itemBuilder: (context, index) {
            return AndroidlargetwoItemWidget();
          },
        ),
      ),
    );
  }
}
